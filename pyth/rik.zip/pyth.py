import pygame as py
import random
import podarok
import webbrowser
import traceback
import time
import sqlite3
py.init()

#con = sqlite3.connect('baze.db')
#cur = con.cursor()
#cur.execute('CREATE TABLE IF NOT EXISTS player(id INTEGER PRIMARY KEY, eat TEXT, cash TEXT, dyma TEXT)')

screen = py.display.set_mode((0, 0), py.RESIZABLE) #Создаем игру размером с экрана игрока (py.FULLSCREEN)(py.RESIZABLE)
bg_img = py.image.load('kosmos-fon-89.jpg')
bg_img = py.transform.scale(bg_img, (screen.get_size())) #Игра
bg_menu = py.image.load('bc.jpg')
bg_menu = py.transform.scale(bg_menu, (screen.get_size())) #Меню
bg_lose = py.image.load('lose.jpg')                                      #Устанавливаем все нужные фоны 
bg_lose = py.transform.scale(bg_lose, (screen.get_size())) #Поражение
bg_win = py.image.load('win.png')
bg_win = py.transform.scale(bg_win, (screen.get_size())) # Победа
py.display.set_caption('Space Invaders') #Установка заголовка игры
clock = py.time.Clock() #Установка частоты кадров
FPS = 180
light_img = [py.image.load('Light0.png'),py.image.load('Light1.png'),py.image.load('Light2.png'),py.image.load('Light3.png'),py.image.load('Light4.png'),py.image.load('Light5.png'),py.image.load('Light6.png'),py.image.load('Light7.png'),py.image.load('Light8.png'),py.image.load('Light9.png'),py.image.load('Light10.png'),]

pos_y = screen.get_size()[1]
pos_x = screen.get_size()[0]    #Сразу считаем скок ху, что бы потом не нагружать игру

kittenimage = py.image.load('Rocket.png')
rockimage = py.image.load('Meteorit.png') # Открываем все нужные нам спрайты

schet = 0 #Счёт игрока
podik = 0 #Шанс удачи получить подарок
podrik = 1 #Поймал ли игрок подарок или нет
mouse_counter = 0
need_draw = False

licenzia_1  ='Играя в эту игру, вы подверждаете, что'
licenzia_2 = 'если ваш корабль сломается, вы не будете переживать'
licenzia_3 = 'за его жизнь'

try:
    class Cat(py.sprite.Sprite):
        def __init__(self,w,h):
            super(Cat, self).__init__()
            self.image = py.transform.scale(kittenimage, (w,h)) #Ставим картинку и размеры персонажу
            self.rect = self.image.get_rect() #Получаем эти самые размеры для столкновений 
            self.rect.x = procent(pos_x,50)
            self.rect.y = procent(pos_y,80)  #Место расположение спрайта

        def update(self):
            self.speedx = 0
            keystate = py.key.get_pressed()   #Движение спрайта
            if keystate[py.K_a] and self.rect[0]-1>-1:
                self.speedx -= 5
            if keystate[py.K_d] and self.rect[0]+1<pos_x-20:
                self.speedx += 5
            self.rect.right+= self.speedx

    class Rock(py.sprite.Sprite):
        def __init__(self,speed_st,speed_end,w,h):
            super(Rock, self).__init__()
            self.image = py.transform.scale(rockimage, (w, h))  #Все тоже самое, что с игроком
            self.rect = self.image.get_rect()
            self.speed_st = speed_st
            self.speed_end = speed_end
            self.speed = round(random.uniform(speed_st, speed_end),1)
            self.rect.x = random.randint(0, pos_x)
            self.rect.y = -150
            
        def update(self):  # Движение метеоритов 
            global schet
            self.rect.y +=self.speed
            if self.rect.y>pos_y:
                self.rect.x = random.randint(0, pos_x-100)
                self.rect.y = -150
                self.speed = round(random.uniform(self.speed_st, self.speed_end),1)
                schet+=1 #Счетчик
                    
    class Button_rect(): 
        def __init__(self, width, height):
            self.width = width
            self.height = height
            #self.inactive_color = (13,162,50)
            self.active_color = (23,204,50)
            self.draw_effects = False
            self.clr_effects = False
            self.rect_h = 10
            self.rect_w = width
        
        def draw(self,x,y,mes,action=None):
            mouse = py.mouse.get_pos() 
            click = py.mouse.get_pressed()
            if x<mouse[0]<x+self.width and y<mouse[1]<y+self.height:
                if click[0]==1:
                    pass  #Потом можно звук добавить
                    if action is not None:
                        action()
                        end_lvl()

            self.draw_beat_rect(mouse[0],mouse[1],x,y)
            print_text(mes=mes,x=x+10,y=y+10,font_size=int((self.width+self.height)//6))

        def draw_beat_rect(self,ms_x,ms_y,x,y):
            if x <= ms_x <= x+self.width and y <= ms_y <= y+self.height:
                self.draw_effects = True

            if self.draw_effects:
                if ms_x < x or ms_x > x + self.width or ms_y < y or ms_y > y + self.height:
                    self.draw_effects = False
                    self.clr_effects = True

                if self.rect_h < self.height:
                    self.rect_h += (self.height-10)/40

            if self.clr_effects and not self.draw_effects:
                if self.rect_h >10:
                    self.rect_h -= (self.height-10)/40
                else:
                    self.clr_effects = False
            draw_y = y + self.height-self.rect_h
            py.draw.rect(screen,self.active_color, (x, draw_y,self.rect_w,self.rect_h))

    def procent(num,proc):
        get = (num/100)*proc
        return get
    
    def tip_quit():
        py.quit()
        quit()

    def anti_show():
        show = False
        return show
    
    def utube():
        webbrowser.open('https://www.youtube.com/channel/UCaIm7MkIwg2vZmbesuX1ZXA', new=0)

    def show_menu(): #Меню для игрока
        show = True
        start_btn = Button_rect(procent(pos_x,13),procent(pos_y,6)) #Кнопки старта и выхода из игры
        quit_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        utube_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        lucuha_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        while show:
            for e in py.event.get():
                if e.type == py.QUIT:
                    tip_quit()
            screen.blit(bg_menu,(0,0))
            start_btn.draw(procent(pos_x,42),procent(pos_y,31),'Старт',vubor_lvl)
            utube_btn.draw(procent(pos_x,42),procent(pos_y,41),'Ютуб',utube)   #Обычное меню для игрока
            lucuha_btn.draw(procent(pos_x,42),procent(pos_y,51),'Лицензия',licuha)
            quit_btn.draw(procent(pos_x,42),procent(pos_y,61),'Выход',tip_quit)
            print_text('@uapb13',procent(pos_x,2),procent(pos_y,5),font_color=(0,255,0))
            draw_ms()
            py.display.update()
            clock.tick(FPS)

    def licuha():
        global licenzia_1,licenzia_2,licenzia_3
        show = True
        back_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        while show:
            screen.blit(bg_menu,(0,0))
            print_text(licenzia_1,procent(pos_x,35),procent(pos_y,31),font_color=(0,255,0))
            print_text(licenzia_2,procent(pos_x,35),procent(pos_y,35),font_color=(0,255,0))
            print_text(licenzia_3,procent(pos_x,35),procent(pos_y,39),font_color=(0,255,0))
            print_text('@uapb13',procent(pos_x,2),procent(pos_y,5),font_color=(0,255,0))
            back_btn.draw(procent(pos_x,42),procent(pos_y,90),'Назад',show_menu)
            py.display.update()
            draw_ms()
            clock.tick(FPS)
            for e in py.event.get():
                if e.type == py.QUIT:
                    tip_quit()

    def vubor_lvl():
        show = True
        lvl1_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        lvl2_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        back_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        while show:
            for e in py.event.get():               #Меню выбора уровня
                if e.type == py.QUIT:
                    tip_quit()
            screen.blit(bg_menu,(0,0))
            lvl1_btn.draw(procent(pos_x,20),procent(pos_y,20),'1 Уровень',lvl_1)
            lvl2_btn.draw(procent(pos_x,35),procent(pos_y,20),'2 Уровень',lvl_2)
            back_btn.draw(procent(pos_x,42),procent(pos_y,90),'Назад',show_menu)
            print_text('@uapb13',procent(pos_x,2),procent(pos_y,5),font_color=(0,255,0))
            draw_ms()
            py.display.update()
            clock.tick(FPS)
                    
    def print_text(mes,x,y,font_color=(0,0,0),font_type=None,font_size=int(procent((pos_x+pos_y)//3,5))): #Создание текста
        font_type = py.font.Font(font_type,font_size)
        text = font_type.render(mes,True,font_color)
        screen.blit(text,(x,y))
        
    cat_size = (int((pos_x+pos_y)//45))
    cat = Cat(cat_size,cat_size*2)
    rocks = py.sprite.Group()
    all_sprites = py.sprite.Group()
    player = py.sprite.Group()
    player.add(cat)
    all_sprites.add(cat)

    def sprite_lvl(num,size):
        for i in range(num):
            r = Rock(2.0, 5.0,size,size) #Минимальная,Максимальная скорость. Размеры
            rocks.add(r)
            all_sprites.add(r)

    def end_lvl():
        global schet
        for helof in rocks:
            helof.kill()
        #cat.kill()
        cat.rect.x = pos_x / 2
        schet = 0

    def nastroiki_lvl(nachalo=(int((pos_x+pos_y)//25)),num_sprite=5,pobeda=25,play_w=1):
        global schet
        back_btn = Button_rect(procent(pos_x,13),procent(pos_y,6))
        bg_y = 0 #С помощью него будет двигаться фон
        r = True #Услвия игры
        play = play_w #Усливие проиграл, выйграл или играет ещё игрок
        nachalo = nachalo #Размер метиорита 
        rocks.remove()
        all_sprites.remove() #Очистить все старые спрайты
        sprite_lvl(num_sprite,nachalo) #Создаем новые спрайты для каждого уровня по разному
        while r:
            if schet >= pobeda: #Счет очков игрока
                play = 3
            if play == 1:
                screen.blit(bg_img, (0, bg_y))
                screen.blit(bg_img, (0, bg_y-pos_y))
                print_text(f'Ваш счет: {schet}',procent(pos_x,5),procent(pos_y,6),font_color=(255,0,0))
                print_text(f'Для победы: {pobeda}',procent(pos_x,5),procent(pos_y,10),font_color=(255,0,0)) #Двигаем фон и отписываем счетчик очков игрока 

                bg_y+=1
                if bg_y >= pos_y: #Движение фона
                    bg_y=0

                hits = py.sprite.spritecollide(cat, rocks, False) #Проверка столкновения игрока с метиоритом
                if hits:
                    play = 2

                back_btn.draw(procent(pos_x,5),procent(pos_y,90),'Назад',show_menu)
                all_sprites.update() #Всё отрисовываем
                all_sprites.draw(screen)

            elif play == 2: #Поражение
                screen.blit(bg_lose,(0,0))
                end_lvl()
                back_btn.draw(procent(pos_x,42),procent(pos_y,90),'Назад',show_menu)

            elif play == 3: #Победа
                screen.fill((255,255,255))
                screen.blit(bg_win,(0,0))
                end_lvl()
                back_btn.draw(procent(pos_x,42),procent(pos_y,90),'Назад',show_menu)

            draw_ms()
            py.display.update()
            clock.tick(FPS)

            for e in py.event.get(): #Ещё одна кнопка
                if e.type == py.QUIT:
                    r = False
                    tip_quit()
    def draw_ms():
        global mouse_counter,need_draw
        mouse = py.mouse.get_pos()
        click = py.mouse.get_pressed()
        mouse_size = [10,12,16,20,28,34,40,48,54,58]

        if click[0] or click[1]:
            need_draw = True
        if need_draw:
            draw_x = mouse[0]-mouse_size[mouse_counter]//2
            draw_y = mouse[1]-mouse_size[mouse_counter]//2
            screen.blit(light_img[mouse_counter],(draw_x,draw_y))
            mouse_counter+=1
            if mouse_counter == 10:
                mouse_counter = 0
                need_draw = False

    def lvl_1():
        nastroiki_lvl(play_w=1) #Создание 1 уровня

    def lvl_2():
        nastroiki_lvl(num_sprite=10,pobeda=50,play_w=1) #Создание 2 уровня

    show_menu()
    tip_quit()
    
except Exception:
    traceback.print_exc()
    time.sleep(50)
    input()